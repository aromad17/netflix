import axios from '../api/axios'
import React, { useEffect, useState } from 'react'
import 'styles/row.css'




function Row({ isLargeRow, title, id, fetchUrl }) {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetchMovieData();
  }, [fetchUrl]);

  const fetchMovieData = async () => {
    const request = await axios.get(fetchUrl);
    setMovies(request.data.results);
    console.log("request =>", request);
    return request;
  }


  return (
    <section className='row'>
      <h2>{title}</h2>
      <div className='slider'>
        <div className='slider__arrow left' onClick={() => { document.getElementById(id).scrollLeft -= (window.innerWidth - 80) }}>
          <span className='arrow' >
            {"<"}
          </span>
        </div>
        <div id={id} className='row__posters'>
          {movies.map((movie) => (
            <img
              key={movie.id}
              className={`row__poster ${isLargeRow && "row__posterLarge"}`}
              src={`https://image.tmdb.org/t/p/original/${isLargeRow ? movie.poster_path : movie.backdrop_path}`}
              loading='lazy'
              alt={movie.title || movie.name || movie.original_name}
            />
          ))}
        </div>

        <div className='slider__arrow right' onClick={() => { document.getElementById(id).scrollLeft += (window.innerWidth - 80) }}>
          <span className='arrow' >
            {">"}
          </span>
        </div>



      </div>

    </section>
  )
}

export default Row